/*
 * GccApplication2.c
 *
 * Created: 03/07/2020 2:08:21 SA
 * Author : nhocm
 */ 

// Khai b�o th� vi?n chu?n
#include <avr/io.h>
#include <math.h>
#define FRE 8
// Khai b�o th�m hai th� vi?n tr�?c th� vi?n ri�ng
#include "hunget_adc.h"
#include "hunget_lcd.h"
#include "thu_vien_rieng.h"
// L?p tr?nh h�m main()
int main()
{
	INIT();
	Dust_Sensor_LCD(20);
	return 0;
}
