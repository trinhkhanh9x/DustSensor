﻿// Khai báo các nguyên m?u hàm
void INIT();
void DELAY_MS(unsigned int mili_count);
void Dust_Sensor(int sampling);
void calc();
void Dust_Sensor_LCD();
void reverse(char* str, int len);
void fl(float n, char* res, int afterpoint);
void L_DELAY(unsigned int l_n);
int intToStr(int x, char str[], int d);
float voMeasuredraw = 0;
float calcVoltage = 0;
float dustDensity = 0;
/**************************************************************************
Hàm INIT() là hàm không có tham s? và không tr? l?i giá tr?, do ngư?i l?p
tr?nh t? xây d?ng đ? kh?i t?o tr?ng thái các PORT c?a vi đi?u khi?n. Như
b?t k? hàm t? xây d?ng nào khác, ngư?i l?p tr?nh có th? đ?i tên, chia nh?,
g?p to, ho?c thay đ?i các l?nh trong hàm này theo d?ng ? riêng khi l?p
tr?nh.
**************************************************************************/
void INIT()
{   int number =1;
	// Kh?i t?o tr?ng thái Output cho các chân n?i t?i các LED đơn
	DDRD |= 0xFF;
	// Kh?i t?o tr?ng thái logic 1 cho các chân n?i t?i các LED đơn
	PORTD |= 0xFF;
	// Kh?i t?o tr?ng thái Output cho các chân n?i t?i LED 7 thanh
	DDRC |= 0xFF;
	// Kh?i t?o tr?ng thái logic 1 cho các chân n?i t?i LED 7 thanh
	PORTC |= 0xFF;
	// Khởi tạo trạng thái input thả nổi cho 8 đầu vào ADC
	DDRA = 0x00;
	PORTA = 0x00;
	// Gọi các hàm khởi tạo tham số cho bộ ADC
	ADC_PRES(128);
	ADC_AVCC();
	ADC_IN(number);
}
void Dust_Sensor(sampling)
{
	float voMeasured = 0;
	for(int i=0;i<sampling;i++)
	{   PORTD =0b01011011;
		L_DELAY(9);
		ADC_STA_CONVERT();
		voMeasured =voMeasured+ADC;
		L_DELAY(2);
		PORTD =0b01011111;
		DELAY_MS(80);
	}
	voMeasuredraw=voMeasured/sampling;
	return(voMeasuredraw);
}
void calc()
{
	calcVoltage = voMeasuredraw * (5.0 / 1024);
	dustDensity = 0.17 * calcVoltage - 0.1;
	if (dustDensity<0)
	dustDensity=0;
	else if (dustDensity>0)
	dustDensity=dustDensity*1000;
	return dustDensity;
}
void Dust_Sensor_LCD(sampling)
{
	
	// Khởi tạo màn hình LCD
	DDRD |= (1<<PD5);
	PORTD &= ~(1<<PD5);
	PORTC |= 0x0F;
	LCD4_INIT(0,0);
	// Hiển thị các dòng text tĩnh
	LCD4_CUR_GOTO(1,0);
	LCD4_OUT_STR("Dust Density ");
	LCD4_CUR_GOTO(2,7);
	LCD4_OUT_STR("PPM");
	//cập nhật giá trị
	for(;;)
	{	
	    Dust_Sensor(sampling);
		calc();
		LCD4_CUR_GOTO(2,0);
		char result[50];
		fl(dustDensity, result, 2);
		LCD4_OUT_STR(result);
		LCD4_OUT_STR("_");
		LCD4_CUR_GOTO(2,12);
		if (dustDensity<=50)
		 LCD4_OUT_STR("G");
		else if(50<dustDensity&&dustDensity<=200)
		 LCD4_OUT_STR("M");
		else if (dustDensity>200&& dustDensity<=300)
		 LCD4_OUT_STR("B");
		else if (dustDensity>300)
		 LCD4_OUT_STR("D");
		DELAY_MS(200);
	}
}
void L_DELAY(unsigned int l_n)
{
	unsigned int i;
	l_n = l_n * FRE;
	for(i=0;i<l_n;i++);
}
void reverse(char* str, int len)
{
	int i = 0, j = len - 1, temp;
	while (i < j) {
		temp = str[i];
		str[i] = str[j];
		str[j] = temp;
		i++;
		j--;
	}
}

// Converts a given integer x to string str[].
// d is the number of digits required in the output.
// If d is more than the number of digits in x,
// then 0s are added at the beginning.
int intToStr(int x, char str[], int d)
{
	int i = 0;
	while (x) {
		str[i++] = (x % 10) + '0';
		x = x / 10;
	}
	
	// If number of digits required is more, then
	// add 0s at the beginning
	while (i < d)
	str[i++] = '0';
	reverse(str, i);
	str[i] = '\0';
	return i;
}

// Converts a floating-point/double number to a string.
void fl(float n, char* res, int afterpoint)
{
	// Extract integer part
	int ipart = (int)n;
	
	// Extract floating part
	float fpart = n - (float)ipart;
	
	// convert integer part to string
	int i = intToStr(ipart, res, 0);
	
	// check for display option after point
	if (afterpoint != 0) {
		res[i] = '.'; // add dot
		
		// Get the value of fraction part upto given no.
		// of points after dot. The third parameter
		// is needed to handle cases like 233.007
		fpart = fpart * pow(10, afterpoint);

		int convert = (int) fpart;
		if(convert == 24 || convert == 49 || convert == 74){
			convert += 1;
		}
		intToStr(convert, res + i + 1, afterpoint);
	}
}
/**************************************************************************
Hàm DELAY_MS() là hàm có tham s? mili_count nhưng không tr? l?i giá tr?, do
ngư?i l?p tr?nh t? xây d?ng đ? t?o ra kho?ng th?i gian tr? (th?i gian ch?)
tính b?ng mili giây. Vi?c tr? đươc th?c hi?n b?ng các v?ng l?p r?ng. V?ng
l?p r?ng (c? th? là v?ng for) tuy không th?c hi?n công vi?c g? nhưng v?n
làm CPU tiêu t?n m?t kho?ng th?i gian nh?t đ?nh cho vi?c kh?i t?o và k?t
thúc. Nhi?u v?ng for liên ti?p s? t?o m?t kho?ng tr? đáng k?.
**************************************************************************/
void DELAY_MS(unsigned int mili_count)
{
	// Khai báo hai bi?n ch?y cho hai v?ng for
	unsigned int i,j;
	// Xung nh?p c?a h? th?ng càng cao, s? v?ng l?p càng tăng
	mili_count = mili_count * FRE;
	for(i = 0; i < mili_count; i++)
	for(j = 0; j < 53; j++);
}
